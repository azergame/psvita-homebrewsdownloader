﻿Public Class gene_gx

End Class